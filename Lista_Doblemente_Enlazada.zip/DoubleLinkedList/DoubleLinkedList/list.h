#ifndef LIST_H
#define LIST_H

#include <iostream>
#include <assert.h>

template <class Type>
class List {
public:
	List() {
		this->first = NULL;
	}
	~List() {
		if(first!=NULL)
			clear();
	}

	void pushFront(const Type& elem) {
		node* aux = new node;

		if (first != NULL)
			first->previous = aux;
		
		aux->value = elem;
		aux->next = first; // the first is null
		aux->previous = NULL;
		first = aux;
	}

	void pushBack(const Type& elem) {
		node* aux = new node;
		aux->value = elem;
		aux->next = NULL;

		if (first == NULL)
		{
			first = aux;
		}
		else
		{
			node* iterator = first;

			while (iterator->next != NULL) {
				iterator = iterator->next;
			}

			iterator->next = aux;
			aux->previous = iterator;
		}
	}

	void popFront() {

		assert(first != NULL); // If first == NULL then abort

		if (first->next != NULL) {
			first = first->next;
			delete first->previous;
			first->previous = NULL;
		}
		else {
			delete first;
			first = NULL;
		}
		
	}

	void popBack() {
		
		assert(first != NULL); // If first == NULL then abort

		node* iterator = first;

		while (iterator->next != NULL) {
			iterator = iterator->next;
		}

		if (iterator == first) {
			delete first;
			first = NULL;
		}
		else {
			iterator = iterator->previous;
			delete iterator->next;
			iterator->next = NULL;
		}
		
	}

	void insert(unsigned int pos, const Type& elem) { // pos of the first element == 0
		if (pos == 0)
			this->pushFront(elem);
		else {

			assert(first != NULL); // If first == NULL then abort

			unsigned int counter = 0;
			node* iterator = first;
			while (counter < pos - 1 && iterator->next != NULL)
			{
				iterator = iterator->next;
				counter++;
			}

			assert(counter == pos - 1); // If counter != pos - 1 then abort

			node* aux = new node;
			node* auxIterator = iterator;
			aux->previous = iterator;
			auxIterator = iterator->next;
			iterator->next = aux;
			auxIterator->previous = aux;
			aux->next = auxIterator;
			aux->value = elem;

		}
	}

	void remove(unsigned int pos) {					 // pos of the first element == 0
		if (pos == 0) {
			this->popFront();
		}
		else {
			assert(first != NULL); // If first == NULL then abort

			unsigned int counter = 0;
			node* iterator = first;
			while (counter < pos - 1 && iterator->next != NULL)
			{
				iterator = iterator->next;
				counter++;
			}

			assert(counter == pos - 1 && iterator->next != NULL); // If counter != pos - 1 then abort

			
			node* auxIterator = iterator;
			auxIterator = iterator->next;
			iterator->next = auxIterator->next;
			node* auxIterator2 = auxIterator;
			if (auxIterator->next != NULL) {
				auxIterator = auxIterator->next;
				auxIterator->previous = iterator;
			}
			delete auxIterator2;
		}
	}

	Type front() const {
		assert(first != NULL); // If first == NULL then abort

		return first->value;
	}

	Type back() const {
		node* iterator = first;

		while (iterator->next != NULL) {
			iterator = iterator->next;
		}

		return iterator->value;
	}

	Type getValue(unsigned int pos) const {			 // pos of the first element == 0

		unsigned int counter = 0;
		node* iterator = first;
		while (counter < pos && iterator->next != NULL)
		{
			iterator = iterator->next;
			counter++;
		}

		assert(counter == pos); // If counter != pos - 1 then abort

		return iterator->value;

	}

	bool empty() const {
		return first == NULL;
	}

	int size() const {
		if (first == NULL)
			return 0;

		unsigned int counter = 1;
		node* iterator = first;
		while (iterator->next != NULL)
		{
			iterator = iterator->next;
			counter++;
		}
		return counter;
	}

	void clear() {

		assert(first != NULL); // If the list is empty abort

		node* iterator = first;
		while (iterator->next != NULL)
		{
			iterator = iterator->next;
			delete iterator->previous;
		}
		delete iterator;

		first = NULL;
		
	}

	void print() const {
		assert(first != NULL); // If the list is empty abort
		cout << "\nPrinting all the list!\n";
		node* iterator = first;
		unsigned int counter = 0;
		while (iterator->next != NULL)
		{
			cout << "Value of list num. " << counter << ": " << iterator->value << endl;
			iterator = iterator->next;
			counter++;
		}

		cout << "Value of list num. " << counter << ": " << iterator->value << endl;

	}

private:
	struct node {
		Type value;
		node* previous;
		node* next;
	};

	node* first;
};

#endif
