#include <iostream>
#include <assert.h>
#include "list.h"

using namespace std;

int main()
{
	List <int>myList;
	
	myList.pushFront(3);
	myList.print();

	myList.pushFront(7);
	myList.print();

	myList.pushBack(9);
	myList.print();

	myList.insert(1, 5);
	myList.print();

	cout << "\nCurrent size of the list: " << myList.size() << endl;

	myList.remove(1);
	myList.print();

	cout << "\nGetting the value of index '2': "<<myList.getValue(2)<<endl;
	cout << "Getting the value of the front: " << myList.front() << endl;
	cout << "Getting the value of the back: " << myList.back() << endl;
	
	cout << "\nPopping back the list! " << endl;
	myList.popBack();
	myList.print();

	cout << "\nPopping front the list! " << endl;
	myList.popFront();
	myList.print();

	cout << "\nCurrent size of the list: " << myList.size() << endl;
	cout << "\nIs the list empty(0=NO / 1 = YES): " << myList.empty() << endl;
	cout << "\nRemoving the last element of the list... \n" << endl;
	myList.popBack();

	cout << "\nCurrent size of the list: " << myList.size() << endl;
	cout << "\nIs the list empty(0=NO / 1 = YES): " << myList.empty() << endl;

	system("pause");
	return 0;
}