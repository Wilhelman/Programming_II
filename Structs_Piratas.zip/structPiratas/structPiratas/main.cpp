#include <iostream>
#include "Point2D.h"

int main() {

	Point2D p1(1, 3), p2(2, 2);
	std::cout << p2.getX() << " " << p2.getY() << std::endl;

	std::cout << p1.getMaxCoord() << std::endl;

	Point2D p3;
	p3 = p1 + p2;

	std::cout << p3.getX() << ", " << p3.getY() << std::endl;

	system("pause");
	return 0;
}