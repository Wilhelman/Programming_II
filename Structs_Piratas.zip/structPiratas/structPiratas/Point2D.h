#ifndef _POINT2D_H_
#define _POINT2D_H_

class Point2D {
private:
	int* coords;
public:
	Point2D() {
		this->coords = new int[2];
		this->coords[0] = 0;
		this->coords[1] = 0;
	}

	Point2D(int x, int y) {
		this->coords = new int[2];
		this->coords[0] = x;
		this->coords[1] = y;
	}

	~Point2D() {
		delete[](this->coords);
	}

	int getX()const {
		return this->coords[0];
	}

	int getY()const {
		return this->coords[1];
	}

	int getMaxCoord()const {
		if (this->coords[0] < this->coords[1])
			return this->coords[1];
		else
			return this->coords[0];
	}

	Point2D operator + (const Point2D& point)const {
		 Point2D p(this->coords[0]+point.coords[0], this->coords[1] + point.coords[1]);
		 return p;
	}
};

#endif // !_POINT2D_H_
