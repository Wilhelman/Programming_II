#include <iostream>
using namespace std;

template <class Type>
class Queue {
public:
	Queue(int maxElems):maxElems(maxElems) {

		this->idEndElem = -1;

		if (maxElems > 0)
			this->queueElems = new Type[maxElems];
		else
			this->queueElems = NULL;

	}

	~Queue() {
		if (this->queueElems != NULL) {
			delete[](this->queueElems);
			this->queueElems = NULL;
		}
	}

	void enqueue(const Type& elem) {

		if (this->idEndElem + 1 < this->maxElems) {
			this->idEndElem++;
			this->queueElems[this->idEndElem] = elem;
		}
		else 
			cout << "Cola llena" << endl;

	}

	Type dequeue() {

		if (this->idEndElem != -1) {

			Type toReturn = this->queueElems[0];

			for (int i = 0; i < this->idEndElem; i++)
			{
				this->queueElems[i] = this->queueElems[i + 1];
			}

			this->idEndElem--;

			return toReturn;
		}

		return 0;
	}

	bool empty() const {
		return this->idEndElem == -1;
	}

	int size() const {
		return this->idEndElem + 1;
	}

	void print() const {
		cout << "Printing the queue: " << endl;
		for (int i = 0; i < this->idEndElem + 1; i++)
		{
			cout << "Value: " << this->queueElems[i] << endl;
		}
	}

private:
	Type* queueElems;
	int maxElems;
	int idEndElem;
};

int main() {

	Queue <int>queue(3);

	queue.enqueue(3);
	queue.enqueue(8);
	queue.enqueue(1);

	queue.print();

	cout << endl;
	cout << "Dequeuing: " << queue.dequeue() << endl;
	cout << endl;

	queue.print();

	cout << endl;
	cout << "Enqueueing: 7" << endl;
	queue.enqueue(7);
	cout << endl;

	queue.print();

	queue.enqueue(8);
	system("pause");
	return 0;
}