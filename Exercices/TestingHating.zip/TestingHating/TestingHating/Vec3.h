#ifndef _VEC3_CLASS_
#define _VEC3_CLASS_

template<class TYPE>

class Vec3
{
private:
	TYPE x, y, z;

public:
	Vec3() { x = y = z = 0; }

	Vec3(TYPE x, TYPE y, TYPE z) : x(x), y(y), z(z) { }

	TYPE getX() const { return x; }
	TYPE getY() const { return y; }
	TYPE getZ() const { return z; }

	void setX(const TYPE& xValue) { x = xValue; }
	void setY(const TYPE& yValue) { y = yValue; }
	void setZ(const TYPE& zValue) { z = zValue; }

	void zero() { x = y = z = 0; }

	bool operator==(const Vec3& v) const
	{
		if (x == v.x && y == v.y && z == v.z)
			return true;
		else
			return false;
	}

	Vec3 operator+(const Vec3& v) const
	{
		Vec3 res;
		res.x = x + v.x;
		res.y = y + v.y;
		res.z = z + v.z;
		return res;
	}

	Vec3 operator+=(const Vec3& v)
	{
		x += v.x;
		y += v.y;
		z += v.z;

		return v;
	}

	Vec3 operator-(const Vec3& v) const
	{
		Vec3 res;
		res.x = x - v.x;
		res.y = y - v.y;
		res.z = z - v.z;
		return res;
	}

	Vec3 operator-=(const Vec3& v)
	{
		x -= v.x;
		y -= v.y;
		z -= v.z;

		return v;
	}

	Vec3 operator*(const TYPE& k) const
	{
		Vec3 res(k*x, k*y, k*z);
		return res;
	}

	Vec3 operator*=(const TYPE& k)
	{
		Vec3 res(x *= k, y *= k, z *= k);
		return res;
	}

	Vec3 operator/(const TYPE& k) const
	{
		Vec3 res(x / k, y / k, z / k);
		return res;
	}

	Vec3 operator/=(const TYPE& k)
	{
		Vec3 res(x /= k, y /= k, z /= k);
		return res;
	}

	float vecNorm() const
	{
		return sqrt(x*x + y*y + z*z);
	}

	TYPE dotProduct(const Vec3& v) const
	{
		return (x*v.x + y*v.y + z*v.z);
	}

	void normalise()
	{
		x /= vecNorm();
		y /= vecNorm();
		z /= vecNorm();
	}

	void displayVector() const
	{
		cout << "Vector: " << this->getX() << "\t" << this->getY() << "\t" << this->getZ() << endl;
	}


};

#endif // _VEC3_CLASS_