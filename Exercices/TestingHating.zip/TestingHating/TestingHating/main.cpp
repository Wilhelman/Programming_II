#include <iostream>

#include "DynArray.h"
#include "LinkedList.h"
#include "Vec3.h"

using namespace std;

int main() {

	Vec3<int> v1(1, 3, 2);
	Vec3<int> v2(1, 3, 2);
	Vec3<int> v3(7, 4, 1);

	Vec3<float> v4(-4.6f, 2.12f, -2.4f);
	Vec3<float> v5(7.0f, 4.25f, -5.98f);

	// Testing gets and sets
	cout << v1.getX() << endl;
	cout << v5.getZ() << endl;
	v5.setZ(-6.0f);
	cout << v5.getZ() << endl;
	v1.zero();
	cout << v1.getY() << endl;

	// Testing operators
	if (v1 == v2)
		cout << "Equals" << endl;
	else
		cout << "Not equals" << endl;

	v1.setX(1);
	v1.setY(3);
	v1.setZ(2);

	if (v1 == v2)
		cout << "Equals" << endl;
	else
		cout << "Not equals" << endl;

	v3 = v1 + v2;
	v3.displayVector();
	v3 -= v2;
	v3.displayVector();
	v3 -= v2;
	v3.displayVector();

	v5.displayVector();
	v5 /= 2;
	v5.displayVector();

	v5 *= 2;
	v5.displayVector();

	v1.displayVector();
	cout << v1.vecNorm() << endl;

	v1.displayVector();
	cout << v1.dotProduct(v1) << endl;

	v4.displayVector();
	v4.normalise();
	v4.displayVector();

	system("pause");

	return 0;
}