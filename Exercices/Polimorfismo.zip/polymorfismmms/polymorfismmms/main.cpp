#include <iostream>
#include "classes.h";

using namespace std;

int main()
{
	Pokemon* pikachu = new ElectricPokemon("Pikachu");
	Pokemon* bulbasur = new GrassPokemon("Bulbasur");
	Pokemon* charmander = new FirePokemon("Charmander");
	Pokemon* squirtle = new WaterPokemon("Squirtle");

	cout << "-- Damage Attacks --" << endl;

	cout << pikachu->getName() << " -> " << bulbasur->getName()
		<< " = " << pikachu->damageAttack(*bulbasur) << " units\n";

	cout << bulbasur->getName() << " -> " << squirtle->getName()
		<< " = " << bulbasur->damageAttack(*squirtle) << " units\n";

	cout << squirtle->getName() << " -> " << charmander->getName()
		<< " = " << squirtle->damageAttack(*charmander) << " units\n";

	cout << charmander->getName() << " -> " << pikachu->getName()
		<< " = " << charmander->damageAttack(*pikachu) << " units\n";

	delete pikachu;
	delete bulbasur;
	delete charmander;
	delete squirtle;

	system("pause");
	return 0;
}
