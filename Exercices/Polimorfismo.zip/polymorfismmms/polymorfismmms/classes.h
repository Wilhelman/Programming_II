#ifndef CLASSES_H
#define CLASSES_H

class Pokemon {
protected:
	char* name;
	char* type;

public:
	Pokemon(char* name):name(name),type("noType"){}

	char* getName() const{
		return name;
	}

	char* getType() const {
		return type;
	}

	virtual int damageAttack(const Pokemon &pokemon)const = 0;
};


class ElectricPokemon: public Pokemon {

public:
	ElectricPokemon(char* name) :Pokemon(name){
		this->type = "Electric";
	}

	int damageAttack(const Pokemon &pokemon) const {
		if (pokemon.getType() == "Grass")
			return 10 / 2;
		else if (pokemon.getType() == "Water")
			return 10 * 2;
		else
			return 10;
	}
};

class GrassPokemon : public Pokemon {

public:
	GrassPokemon(char* name) :Pokemon(name) {
		this->type = "Grass";
	}

	int damageAttack(const Pokemon &pokemon) const {
		if (pokemon.getType() == "Fire")
			return 10 / 2;
		else if (pokemon.getType() == "Water")
			return 10 * 2;
		else
			return 10;
	}
};

class FirePokemon : public Pokemon {

public:
	FirePokemon(char* name) :Pokemon(name) {
		this->type = "Fire";
	}

	int damageAttack(const Pokemon &pokemon) const {
		if (pokemon.getType() == "Water")
			return 10 / 2;
		else if (pokemon.getType() == "Grass")
			return 10 * 2;
		else
			return 10;
	}
};

class WaterPokemon : public Pokemon {

public:
	WaterPokemon(char* name) :Pokemon(name) {
		this->type = "Water";
	}

	int damageAttack(const Pokemon &pokemon) const {
		if (pokemon.getType() == "Grass")
			return 10 / 2;
		else if (pokemon.getType() == "Fire")
			return 10 * 2;
		else
			return 10;
	}
};

#endif // !CLASSES_H
