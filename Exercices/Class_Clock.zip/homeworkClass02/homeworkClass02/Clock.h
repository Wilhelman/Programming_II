#ifndef _CLOCK_H_
#define _CLOCK_H_

class Clock {
private:
	unsigned short hours;
	unsigned short minutes;
	unsigned short seconds;

public:
	//constructors
	Clock();
	Clock(unsigned short hours, unsigned short minutes, unsigned short seconds);
	Clock(const Clock& clock) {
		this->hours = clock.hours;
		this->minutes = clock.minutes;
		this->seconds = clock.seconds;
	}

	//getters
	unsigned short getHours()const;
	unsigned short getMinutes()const;
	unsigned short getSeconds()const;

	//setter
	void setHour(unsigned short hours, unsigned short minutes, unsigned short seconds);

	//operators
	bool operator == (const Clock& clock)const{
		if (this->hours == clock.hours && this->minutes == clock.minutes && this->seconds == clock.seconds)
			return true;
		else
			return false;
	}
	bool operator < (const Clock& clock)const{
		if (this->hours < clock.hours)
			return true;
		else if (this->hours > clock.hours)
			return false;
		else if (this->minutes < clock.minutes)
			return true;
		else if (this->minutes > clock.minutes)
			return false;
		else if (this->seconds < clock.seconds)
			return true;
		else
			return false;
	}
	bool operator > (const Clock& clock)const{
		if (this->hours > clock.hours)
			return true;
		else if (this->hours < clock.hours)
			return false;
		else if (this->minutes > clock.minutes)
			return true;
		else if (this->minutes < clock.minutes)
			return false;
		else if (this->seconds > clock.seconds)
			return true;
		else
			return false;
	}

	//other
	void printHour()const;
};

#endif // !_CLOCK_H_

