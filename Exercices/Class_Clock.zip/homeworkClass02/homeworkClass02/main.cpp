#include <iostream>
#include "Clock.h"
#include <string> 



using namespace std;

int main() {

	Clock cassio;
	Clock rolex(23, 59, 59);
		
	if (cassio == rolex)
		cout << "Are equal" << endl;
	else
		cout << "The clocks are not equal" << endl;

	rolex.setHour(22, 19, 23);

	if (rolex < cassio)
		cout << "Rolex esta atrasado respecto Cassio" << endl;
	else
		cout << "Rolex NO esta atrasado respecto Cassio" << endl;

	rolex.printHour();
	
	system("pause");
	return 0;
}