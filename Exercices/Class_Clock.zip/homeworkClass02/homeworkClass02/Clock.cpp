#include "Clock.h"
#include <iostream>

Clock::Clock() {
	this->hours = 23;
	this->minutes = 59;
	this->seconds = 59;
}

Clock::Clock(unsigned short hours, unsigned short minutes, unsigned short seconds) {
	this->hours = hours;
	this->minutes = minutes;
	this->seconds = seconds;
}

unsigned short Clock::getHours()const {

	return this->hours;
}

unsigned short Clock::getMinutes()const {
	return this->minutes;
}

unsigned short Clock::getSeconds()const {
	return this->seconds;
}

void Clock::setHour(unsigned short hours, unsigned short minutes, unsigned short seconds) {
	this->hours = hours;
	this->minutes = minutes;
	this->seconds = seconds;
}

void Clock::printHour()const{
	std::cout << this->hours << ":" << this->minutes << ":" << this->seconds << std::endl;
}