#ifndef __PLAYER_H__
#define __PLAYER_H__

#include "Item.h"

class Player {

private:
	char* name;
	unsigned short numLifes;
	bool invincible;
	bool* capabilities;
	bool* weapon;

public:
	Player(char* name) :name(name) {
		numLifes = 3;
		invincible = false;
		capabilities = new bool[3];
		weapon = new bool[3];
		for (int i = 0; i < 3; i++)
		{
			capabilities[i] = false;
			weapon[i] = false;
		}
		capabilities[1] = true;
	}

	~Player() {
		delete[] capabilities;
		delete[] weapon;
	}

	char* getName()const {
		return this->name;
	}

	void printNumLifes() const{
		std::cout << this->name << " HAVE " << this->numLifes<< " LIVES" << std::endl;
	}

	void printInvincible() const{
		if(invincible)
			std::cout << this->name << " IS INVINCIBLE!" << std::endl;
		else
			std::cout << this->name << " IS NOT INVINCIBLE!" << std::endl;
	}

	void printCapabilities() const{
		for (int i = 0; i < 3; i++)
		{
			if (capabilities[i] == true) {
				switch (i)
				{
				case 0:
					std::cout << this->name << " IS MINI!" << std::endl;
					break;
				case 1:
					std::cout << this->name << " IS NORMAL!" << std::endl;
					break;
				case 2:
					std::cout << this->name << " IS MAXI!" << std::endl;
					break;
				default:
					break;
				}
			}
		}
	}

	void printWeapon() const{
		for (int i = 0; i < 3; i++)
		{
			if (weapon[i] == true) {
				switch (i)
				{
				case 0:
					std::cout << this->name << " SHOTS FIRE BALLS!" << std::endl;
					break;
				case 1:
					std::cout << this->name << " SHOTS ICE BALLS!" << std::endl;
					break;
				case 2:
					std::cout << this->name << " SHOTS GOLDEN BALLS!" << std::endl;
					break;
				default:
					break;
				}
			}
		}
	}

	bool operator ==(const Player& player) const {
		if (this->getName() == player.getName())
			return true;
		else
			return false;
	}

	void useItem(const Item& item) {
		if (strcmp(item.name, "One_Up") == 0)
			this->numLifes++;
		else if (strcmp(item.name, "Mini_Mario") == 0) {
			for (int i = 0; i < 3; i++)
			{
				if (i == 0)
					capabilities[i] = true;
				else
					capabilities[i] = false;
			}
		}
		else if (strcmp(item.name, "Super_Mario") == 0) {
			for (int i = 0; i < 3; i++)
			{
				if (i == 2)
					capabilities[i] = true;
				else
					capabilities[i] = false;
			}
		}
		else if (strcmp(item.name, "Fire_Flower") == 0) {
			for (int i = 0; i < 3; i++)
			{
				if (i == 0)
					weapon[i] = true;
				else
					weapon[i] = false;
			}
		}
		else if (strcmp(item.name, "Ice_Flower") == 0) {
			for (int i = 0; i < 3; i++)
			{
				if (i == 1)
					weapon[i] = true;
				else
					weapon[i] = false;
			}
		}
		else if (strcmp(item.name, "Golder_Flower") == 0) {
			for (int i = 0; i < 3; i++)
			{
				if (i == 2)
					weapon[i] = true;
				else
					weapon[i] = false;
			}
		}
	}

	friend void starTouched (Player& player);

};

#endif // !__PLAYER_H__
