#include <iostream>
#include "Player.h"
#include <stdio.h>

#define NUM_ITEMS 6

using namespace std;

void starTouched(Player& player) {
	player.invincible = true;
}

int main() {

	char* items[NUM_ITEMS]{ "One_Up","Mini_Mario","Super_Mario","Fire_Flower","Ice_Flower","Golden_Flower" };

	cout << "Introduce el nombre del jugador: ";
	char nameUser[50];
	cin >> nameUser;

	Player p(nameUser);

	bool quit = false;
	while (!quit) {

		char response[50];
		bool goodResponse = false;

		cout << "\nIntroduce the name of an Item ('One_Up' , 'Mini_Mario', 'Super_Mario', 'Fire_Flower', 'Ice_Flower', 'Golden_Flower'\nOR give to your player a 'Star'\nOR 'Quit' to exit the game :c\nYou: ";
		cin >> response;

		for (int i = 0; i < NUM_ITEMS; i++)
		{
			if (strcmp(response, items[i]) == 0) {
				p.useItem(response);
				goodResponse = true;
			}
		}

		if (strcmp(response, "Star") == 0) {
			starTouched(p);
			goodResponse = true;
		}

		if (strcmp(response, "Quit") == 0) {
			quit = true;
			goodResponse = true;
		}

		if (!quit && goodResponse) {
			cout << endl;
			p.printNumLifes();
			p.printCapabilities();
			p.printWeapon();
			p.printInvincible();
		}
		if (!goodResponse) {
			cout << endl;
			cout << "What are you saying? Please write it correctly!" << endl;
		}
	}

	cout << "Bye bye!!" << endl;

	system("pause");
	return 0;
}