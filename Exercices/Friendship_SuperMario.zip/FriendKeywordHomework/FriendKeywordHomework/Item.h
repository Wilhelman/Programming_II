#ifndef __ITEM_H__
#define __ITEM_H__



class Item {

	friend class Player;

private:
	char* name;

public:
	Item(char* name) :name(name){}
	~Item(){}
};

#endif // !__ITEM_H__