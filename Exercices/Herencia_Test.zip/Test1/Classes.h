/* ----------------------------------------------------------------------- */
/*                         GUILLERMO GARCIA SUBIRANA                           */
/* ----------------------------------------------------------------------- */

#ifndef CLASSES_H
#define CLASSES_H

#define CVU_Bayonet_Soldier 1
#define CVU_Musket_Soldier 2
#define CVU_Light_Chivalry_Horse_Rider 3
#define CVU_Heavy_Chivalry_Horse_Rider 4
#define CVU_Mortar 5
#define CVU_Cannon 6

// TO DO: Implement the base class Battalion here
class Battalion {
protected:
	char* name;

public:
	Battalion(char* name):name(name){}

	char* getName() const{
		return this->name;
	}

	virtual int combatValue() = 0;
};



// TO DO: Implement the derived class Infantry here
class Infantry : public Battalion {
private:
	int bayonetSoldiers;
	int musketSoldiers;

public:
	Infantry(char* name, int bayonetSoldiers, int musketSoldiers):Battalion(name), bayonetSoldiers(bayonetSoldiers), musketSoldiers(musketSoldiers){}

	int combatValue() {
		return bayonetSoldiers * CVU_Bayonet_Soldier + musketSoldiers * CVU_Musket_Soldier;
	}
};



// TO DO: Implement the derived class Chivalry here
class Chivalry : public Battalion {
private:
	int lightChivalry;
	int heavyChivalry;

public:
	Chivalry(char* name, int lightChivalry, int heavyChivalry) :Battalion(name), lightChivalry(lightChivalry), heavyChivalry(heavyChivalry) {}

	int combatValue() {
		return lightChivalry * CVU_Light_Chivalry_Horse_Rider + heavyChivalry * CVU_Heavy_Chivalry_Horse_Rider;
	}
};


// TO DO: Implement the derived class Artillery here
class Artillery : public Battalion {
private:
	int mortars;
	int cannons;

public:
	Artillery(char* name, int mortars, int cannons) :Battalion(name), mortars(mortars), cannons(cannons) {}

	int combatValue() {
		return mortars * CVU_Mortar + cannons * CVU_Cannon;
	}
};


char* victoryInBattlefield(Battalion* div1, Battalion* div2)
{
	// TO DO: introduce the code of the function here
	if (div1->combatValue() < div2->combatValue())
		return div2->getName();
	else if (div1->combatValue() > div2->combatValue())
		return div1->getName();
	else
		return "Same combat value";
}


#endif // CLASSES_H