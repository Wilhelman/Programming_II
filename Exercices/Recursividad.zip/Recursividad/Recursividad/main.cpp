#include <iostream>

unsigned int factorial(unsigned int n) {
	if (n == 1 || n == 0) {
		return 1;
	}
	else {
		return n * factorial(n - 1);
	}
}

void countDown(unsigned int num) {
	std::cout << num << std::endl;
	if (num > 0)
		countDown(num - 1);
}

void countUp(unsigned int max, int num) {

	std::cout << num << std::endl;
	if (num < max)
		countUp(max,num + 1);
}

int main() {
	std::cout << "***Factorial (4)***" << std::endl;
	std::cout << factorial(4) << std::endl;
	std::cout << "\n***Count Down***" << std::endl;
	countDown(10);
	std::cout <<"\n***Count Up***" << std::endl;
	countUp(10, 0);

	system("pause");
	return 0;
}