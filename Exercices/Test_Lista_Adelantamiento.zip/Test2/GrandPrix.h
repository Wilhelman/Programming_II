/* ----------------------------------------------------------------------- */
/*                        INSERT YOUR NAME HERE                            */
/* ----------------------------------------------------------------------- */

#ifndef GRANDPRIX_H
#define GRANDPRIX_H

#include <iostream>

class GrandPrix{
public:
	GrandPrix();
	~GrandPrix();

	void pushBack(char* pilot);
	int getPositionPilot(char* pilot) const;		// position of the leader == 0
	bool isLastPilot(char* pilot) const;
	void printNodes() const;

	void overtake(char* pilot);

private:
	struct node{
		char* pilot;
		node* previous;
		node* next;
	};

	node* first;
};


GrandPrix::GrandPrix()
{
	this->first = NULL;
}


GrandPrix::~GrandPrix()
{
	while (first != NULL)
	{
		node* aux = first;
		first = first->next;
		delete aux;
	}
}


void GrandPrix::pushBack(char* pilot)
{
	node* aux = new node;
	aux->pilot = pilot;
	aux->next = NULL;

	if (first == NULL)
	{
		aux->previous = NULL;
		first = aux;
	}
	else
	{
		node* iterator = first;
		while (iterator->next != NULL)
			iterator = iterator->next;

		aux->previous = iterator;
		iterator->next = aux;
	}
}


int GrandPrix::getPositionPilot(char* pilot) const
{
	if (first != NULL)
	{
		unsigned int position = 0;
		node* iterator = first;
		bool pilotFound = strcmp(iterator->pilot, pilot) == 0;
		while (!pilotFound && iterator->next != NULL)
		{
			position++;
			iterator = iterator->next;
			pilotFound = strcmp(iterator->pilot, pilot) == 0;
		}

		if (iterator->next == NULL && !pilotFound)
			return -1;
		else
			return position;
	}
	else
	{
		std::cout << "ERROR getPositionPilot(...): empty Grand Prix" << std::endl;
		return -1;
	}
	
}


bool GrandPrix::isLastPilot(char* pilot) const
{
	if (first != NULL)
	{
		node* iterator = first;
		bool pilotFound = strcmp(iterator->pilot, pilot) == 0;
		while (!pilotFound && iterator->next != NULL)
		{
			iterator = iterator->next;
			pilotFound = strcmp(iterator->pilot, pilot) == 0;
		}

		if (iterator->next == NULL)
			return true;
		else
			return false;
	}
	else
	{
		std::cout << "ERROR isLastPilot(...): empty Grand Prix" << std::endl;
		return false;
	}
}


void GrandPrix::printNodes() const
{
	if (first == NULL)
	{
		std::cout << "The Grand Prix is EMPTY" << std::endl;
	}
	else
	{
		std::cout << std::endl;

		node* iterator = first;
		while (iterator != NULL)
		{
			if (iterator->previous == NULL)
				std::cout << "<-| NULL | ";
			else
				std::cout << "<-| @node " << iterator->previous->pilot << " | ";

			std::cout << iterator->pilot;

			if (iterator->next == NULL)
				std::cout << " | NULL |->\n";
			else
				std::cout << " | @node " << iterator->next->pilot << " |->" << std::endl;

			iterator = iterator->next;
		}

		std::cout << std::endl;
	}
}


void GrandPrix::overtake(char* pilot)
{
	node* iterator = first;
	while (iterator->next != NULL && iterator->pilot != pilot) {
		iterator = iterator->next;
	}
	
	if (iterator->pilot == pilot && iterator != first) {
		node*auxOvertaken = iterator->previous;
		if (auxOvertaken->previous != NULL) {
			node*auxPrev = auxOvertaken->previous;
			iterator->previous = auxPrev;
			auxPrev->next = iterator;
		}
		else {
			first = iterator;
			iterator->previous = NULL;
		}
		
		if (iterator->next != NULL) {
			node*auxNext = iterator->next;
			auxOvertaken->next = auxNext;
			auxNext->previous = auxOvertaken;
		}
		else
			auxOvertaken->next = NULL;

		iterator->next = auxOvertaken;
		auxOvertaken->previous = iterator;
	}

}


#endif
