#include "GrandPrix.h"
#include "SimpleUnitTest.h"

void testExercises();

int main()
{
	/* -- Auto evaluation -- */
	/* Uncomment the line below if you want to evaluate your code */
	testExercises();

	system("pause");
	return 0;
}


/* ----------------------------------------------------------------------- */
/*                     DO NOT TOUCH THE CODE BELOW                         */
/* ----------------------------------------------------------------------- */

void testExercises()
{
	GrandPrix gp;

	gp.pushBack("Rosberg");
	gp.pushBack("Verstappen");
	gp.pushBack("Sainz");
	gp.pushBack("Hulkenberg");
	gp.pushBack("Alonso");

	gp.overtake("Rosberg");
	TEST(": OVERTAKE - first pilot (He can not overtake, the classification must remain equal!)", 
		gp.getPositionPilot("Rosberg") == 0 &&
		gp.getPositionPilot("Verstappen") == 1 &&
		gp.getPositionPilot("Sainz") == 2 &&
		gp.getPositionPilot("Hulkenberg") == 3 &&
		gp.getPositionPilot("Alonso") == 4 &&
		gp.isLastPilot("Alonso") == true);

	gp.overtake("Alonso");
	TEST(": OVERTAKE - last pilot", 
		gp.getPositionPilot("Rosberg") == 0 &&
		gp.getPositionPilot("Verstappen") == 1 &&
		gp.getPositionPilot("Sainz") == 2 &&
		gp.getPositionPilot("Alonso") == 3 &&
		gp.getPositionPilot("Hulkenberg") == 4 &&
		gp.isLastPilot("Hulkenberg") == true);

	gp.overtake("Alonso");
	
	bool ov1 = gp.getPositionPilot("Rosberg") == 0 &&
			   gp.getPositionPilot("Verstappen") == 1 &&
			   gp.getPositionPilot("Alonso") == 2 &&
			   gp.getPositionPilot("Sainz") == 3 &&
			   gp.getPositionPilot("Hulkenberg") == 4 &&
			   gp.isLastPilot("Hulkenberg") == true;

	gp.overtake("Alonso");

	ov1 = ov1 && gp.getPositionPilot("Rosberg") == 0 &&
		  gp.getPositionPilot("Alonso") == 1 &&
		  gp.getPositionPilot("Verstappen") == 2 &&
		  gp.getPositionPilot("Sainz") == 3 &&
		  gp.getPositionPilot("Hulkenberg") == 4 &&
		  gp.isLastPilot("Hulkenberg") == true;
	
	gp.overtake("Alonso");
	
	ov1 = ov1 && gp.getPositionPilot("Alonso") == 0 &&
		gp.getPositionPilot("Rosberg") == 1 &&
		gp.getPositionPilot("Verstappen") == 2 &&
		gp.getPositionPilot("Sainz") == 3 &&
		gp.getPositionPilot("Hulkenberg") == 4 &&
		gp.isLastPilot("Hulkenberg") == true;

	gp.overtake("Alonso");

	ov1 = ov1 && gp.getPositionPilot("Alonso") == 0 &&
		gp.getPositionPilot("Rosberg") == 1 &&
		gp.getPositionPilot("Verstappen") == 2 &&
		gp.getPositionPilot("Sainz") == 3 &&
		gp.getPositionPilot("Hulkenberg") == 4 &&
		gp.isLastPilot("Hulkenberg") == true;
	
	gp.overtake("Sainz");

	ov1 = ov1 && gp.getPositionPilot("Alonso") == 0 &&
		gp.getPositionPilot("Rosberg") == 1 &&
		gp.getPositionPilot("Sainz") == 2 &&
		gp.getPositionPilot("Verstappen") == 3 &&
		gp.getPositionPilot("Hulkenberg") == 4 &&
		gp.isLastPilot("Hulkenberg") == true;

	gp.overtake("Hulkenberg");

	ov1 = ov1 && gp.getPositionPilot("Alonso") == 0 &&
		gp.getPositionPilot("Rosberg") == 1 &&
		gp.getPositionPilot("Sainz") == 2 &&
		gp.getPositionPilot("Hulkenberg") == 3 &&
		gp.getPositionPilot("Verstappen") == 4 &&
		gp.isLastPilot("Verstappen") == true;

	TEST(": OVERTAKE - intermediate pilots", ov1 == true);

	PRINT_TEST_REPORT();
}