#ifndef _BUILDINGS_H_
#define _BUILDINGS_H_

#include <iostream>

class Building {
protected:
	char* name;

public:
	Building(char* name): name(name){}
	
	char* getName() const{
		return this->name;
	}
};

class Warehouse : public Building {
private:
	int wood, rocks, wheat;

public:
	Warehouse(char* name, int wood, int rocks, int wheat) :Building(name), wood(wood), rocks(rocks), wheat(wheat) {}

	void printResources() const{
		std::cout << "-- " << this->name << " --\nWood: " << this->wood << "\nRocks: " << this->rocks << "\nWheat: " << this->wheat << std::endl;
	}
};

class House : public Building {
private:
	int floors, inhabitants, servants;

public:
	House(char* name, int floors, int inhabitants, int servants) :Building(name), floors(floors), inhabitants(inhabitants), servants(servants) {}

	void printHouse() const{
		std::cout << "-- " << this->name << " --\nFloors: " << this->floors << "\nInhabitants: " << this->inhabitants << "\nServants: " << this->servants << std::endl;
	}
};

class Temple :public Building {
private:
	char* god;
	int priests;

public:
	Temple(char* name, char* god, int priests) :Building(name), god(god), priests(priests){}

	void printTemple() const {
		std::cout << "-- " << this->name << " --\nGod: " << this->god << "\nPriests: " << this->priests << std::endl << std::endl;
	}
};


#endif // !_BUILDINGS_H_
